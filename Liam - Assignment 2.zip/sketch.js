function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(50);
  colorMode(RGB,255,255,255,1);
  strokeWeight(2);
  stroke(213,135,242,0.6);
  fill(133,134,214);
  triangle(23,23,64,54,30,65);
  noFill();
  stroke(222,122,22,1);
  curve(120,50,100,100,88,20,75,60);
  stroke(50,77,123,1);
  fill(77,77,177);
  quad(20,120,60,108,80,121,86,90);
}