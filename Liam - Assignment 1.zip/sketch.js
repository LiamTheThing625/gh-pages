function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(51);
  strokeWeight(1.5);
  stroke(28);
  fill(77);
  rect(0,32,32,96);
  rect(96,50,32,78);
  fill(169);
  rect(16,80,64,48);
  rect(46,66,46,62);
  fill(58);
  rect(62,93,54,35);
  strokeWeight(2.4);
  strokeCap(ROUND);
  line(16,32,16,16);
  fill('rgb(255,255,255)')
  strokeWeight(0);
  circle(112,15,24);
}