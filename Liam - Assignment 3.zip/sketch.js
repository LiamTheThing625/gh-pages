function setup() {
  createCanvas(400, 400);
  
  
  
  frameRate(15);
  
  
}

function draw() {
  let x = mouseX;
  let y = mouseY;
  let z = (mouseX+mouseY)/2;
  background(100);
  colorMode(RGB,255);
  color(255,255,9)
  fill(0,0,255)
  square(x,y,z);
  fill(255,0,0)
  square(y-50,z-50,x-50);
  fill(255,255,0)
  square(mouseX, mouseY, pmouseX, pmouseY);
  fill(0,255,0)
  square(pow(mouseX/200,mouseY/200),abs(mouseX-100,mouseY-100),x+y-z);
}